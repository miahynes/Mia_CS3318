package com.example.mia_cs3318;

import java.util.IllegalFormatException;

public interface UserInterface {
    interface ModelInterface{
        public void setEmail(String email) throws IllegalFormatException, InvalidEmail;
        public void setPassword(String password) throws IllegalFormatException, InvalidPassword;
        public String getEmail();
        public String getPassword();

    }

    interface PresenterInterface{
        public Boolean updatePassword(String password);
        public Boolean updateEmail(String email);
    }

    interface ViewInterface{
        public void onDestroy();
    }
}

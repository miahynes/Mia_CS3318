module com.example.mia_cs3318 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.mia_cs3318 to javafx.fxml;
    exports com.example.mia_cs3318;
}
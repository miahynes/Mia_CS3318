package com.example.mia_cs3318;
import java.util.regex.Pattern;

public class Model implements UserInterface.ModelInterface {
    private String email;
    private String password;

    public Model(){
        this.email = "";
        this.password = "";
    }

    @Override
    public String getEmail(){
        return this.email;
    }

    @Override
    public void setEmail(String email) throws InvalidEmail{
        Pattern emailPattern = Pattern.compile("^([a-zA-Z0-9_\\-.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(]?)(]?)$");
        if(!emailPattern.matcher(email).find()){
            throw new InvalidEmail("Error: invalid email format.");
            //System.out.println("error invalid email");
        }else{
            this.email = email;
        }
    }

    @Override
    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) throws InvalidPassword {
        Pattern passwordPattern = Pattern.compile("^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[*^&@!]).{7,}$");
        if(!passwordPattern.matcher(password).matches()){
            throw new InvalidPassword("Error: Invalid password format.");
           // System.out.println("invalid password");
        }else{
            this.password = password;
        }
    }

    @Override
    public String toString() {
        return "Email : " + email + "\nPassword : " + password;
    }
}

package com.example.mia_cs3318;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import java.io.IOException;

public class View extends Application implements UserInterface.ViewInterface{

    Presenter myPresenter = new Presenter();
    Stage stage;

    @Override
    public void start(Stage stage) throws IOException {

        this.stage = stage;
        Label emailLabel = new Label("Email : ");
        Label passwordLabel = new Label("Password : ");
        TextField emailText = new TextField();
        PasswordField passwordText = new PasswordField();
        emailText.setPromptText("Please enter email.");
        passwordText.setPromptText("Please enter password.");
        Label loginLabel = new Label();
        Button loginButton = new Button("Login!");

        loginButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                String email = emailText.getText();
                String password = passwordText.getText();
                //add in checks and errors with if statements
                Boolean emailCheck = myPresenter.updateEmail(email);
                Boolean passwordCheck = myPresenter.updatePassword(password);
                if(emailCheck & passwordCheck){
                    loginLabel.setText("Login successful!");
                }else if(!emailCheck&!passwordCheck){
                    loginLabel.setText("Error: invalid email and password. Please try again.");
                    emailText.setText("");
                    passwordText.setText("");
                }else if (!emailCheck){
                    loginLabel.setText("Error: invalid email. Please try again.");
                    emailText.setText("");
                }else {
                    loginLabel.setText("Error: invalid password. Please try again.");
                    passwordText.setText("");
                }
            }
        });
        GridPane grid = new GridPane();
        grid.addRow(0, emailLabel, emailText);
        grid.addRow(1, passwordLabel, passwordText);
        grid.addRow(2, loginButton);
        grid.addRow(2, loginLabel);
        Scene scene = new Scene(grid, 320, 240);
        stage.setTitle("Login Page: Java CA3");
        stage.setScene(scene);
        stage.show();
    }

   // public static void main(String[] args) {
   //     launch();
   // }
    @Override
    public void onDestroy() {

    }
}
package com.example.mia_cs3318;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

class ModelTest {

    private Model model;

    @BeforeEach
    void setUp() {
        this.model = new Model();
    }

    @org.junit.jupiter.params.ParameterizedTest
    @ValueSource(strings = {"email","email@gmail", "email.com","emailgmail.com", "email.com@gmail", "@gmail.com"})
    void setInvalidEmail(String email){
        assertThrows(InvalidEmail.class, () -> model.setEmail(email));
    }

    @org.junit.jupiter.params.ParameterizedTest
    @ValueSource(strings = {"password","PASSWORD", "1234567","Password123", "pass", "Password!!"})
    void setInvalidPassword(String password){
        assertThrows(InvalidPassword.class, () -> model.setPassword(password));
    }

    @org.junit.jupiter.params.ParameterizedTest
    @ValueSource(strings = {"Password2021!", "PASSword2*", "AbcD123!"})
    void setValidPassword(String password) {
        try{
            model.setPassword(password);
        } catch (InvalidPassword e) {
            e.printStackTrace();
            fail();
        }
    }
}
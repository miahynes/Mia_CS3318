package com.example.mia_cs3318;

public class InvalidPassword extends Exception{
    public InvalidPassword(String message){
        super(message);
    }
}

package com.example.mia_cs3318;

public class InvalidEmail extends Exception{
    public InvalidEmail(String message){
        super(message);
    }
}

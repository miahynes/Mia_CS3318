package com.example.mia_cs3318;


public class Presenter implements UserInterface.PresenterInterface{

    private final Model model;
    //private View view;

    public Presenter() {
        this.model = new Model();
        //this.view = view;
    }

    @Override
    public Boolean updateEmail(String email){
        try{
            model.setEmail(email);
            return true;
        } catch(InvalidEmail e) {
            return false;
        }
    }

    @Override
    public Boolean updatePassword(String password){
        try{
            model.setPassword(password);
            return true;
        } catch(InvalidPassword e){
            return false;
        }
    }
}